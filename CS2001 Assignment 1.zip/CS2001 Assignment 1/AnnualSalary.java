import java.util.Scanner;
public class AnnualSalary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		String salesPerson;
		final double MONTHS = 12;
		final double MONTHLYRATE = 2500 * MONTHS;
		final double MONEYPERCAR = 150;
		final double PERCENTPERCAR = 0.10;
		// Initializing constants
		double carsSold;
		double totalSales;
		double moneyfromCars;
		double totalCommission;
		double totalEarnings;
		// Initializing values
		System.out.println("Enter the name of the Sales Person");
		salesPerson = in.next();
		System.out.println("How many cars did " + salesPerson + " Sell?");
		carsSold = in.nextDouble();
		System.out.println("What was the Total price of all cars sold?");
		totalSales = in.nextDouble();
		// Here the the user enters the value of the inputs
		moneyfromCars = (double) (MONEYPERCAR * carsSold);
		totalCommission = (double) (totalSales * PERCENTPERCAR);
		totalEarnings = (double) (MONTHLYRATE + totalCommission + moneyfromCars);
		// The calculations to get the total earnings of the sales person this year!
		System.out.println(salesPerson + " earned " + totalEarnings + " This year!");
	}

}