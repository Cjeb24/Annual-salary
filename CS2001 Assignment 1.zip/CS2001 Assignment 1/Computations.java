import java.util.Scanner;

public class Computations {
	public static void main(String[] args) {
		// This is a program the computes a number entered by the user
		// Then does some computations that ends with the starting number
		int startnum;
		int answer;
		// Above is the initializing step 
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a number >=0");
		startnum = in.nextInt();
		// Above is the steps for the user entered data
		answer = (int) (startnum * 5);
		answer = (int) (answer + 6);
		answer = (int) (answer * 4);
		answer = (int) (answer + 9);
		answer = (int) (answer * 5);
		answer = (int) (answer / 100);
		answer = (int) (answer - 1);
		// Above is the steps for the computations
		// Each done as a separate line as to see exactly what is happening
		System.out.println("The answer is " + answer);
		// This is the step that outputs the final number
	}
}