import java.util.Scanner;
public class TravelCosts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/* this program takes user input for the amount of people going on vacation
		 * and then takes these values and computes the total travel cost */
		Scanner in = new Scanner(System.in);
		final int ROUNDTRIP = 900;
		final int HOTELROOM = 700;
		//Initializing Constants
		int adults;
		int child;
		double totalHotel = 0;
		double totalAirFare = 0;
		double totalCost = 0;
		// Initializing the required values
		System.out.println("How many adults are going on your trip?");
		adults = in.nextInt();
		System.out.println("How many children are going on your trip?");
		child = in.nextInt();
		// The User inputs the amount of adults and children going on vacation
		if (adults == 2) {
			totalHotel += (HOTELROOM + (HOTELROOM * 0.6));
			totalAirFare += (ROUNDTRIP * 2);
		}  else if (adults == 1) {
			totalHotel += HOTELROOM;
			totalAirFare += ROUNDTRIP;	
		} // This will calculate the total cost for the adults
		if (child == 2) {
			totalAirFare += ((ROUNDTRIP * 0.5) * 2);	
		} else if (child == 1) {
			totalAirFare += (ROUNDTRIP * 0.5);
		} // This will calculate the total cost for the Children
		System.out.println("The total AirFare is " + totalAirFare);
		System.out.println("The total hotel cost is " + totalHotel);
		System.out.println("your total cost is " + (totalAirFare + totalHotel));
		//this is the output statements
	}

}
